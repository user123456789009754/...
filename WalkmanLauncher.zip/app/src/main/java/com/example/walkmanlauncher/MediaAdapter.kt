package com.example.walkmanlauncher

import android.net.Uri
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView

class MediaAdapter(private val items: List<Pair<String, Uri>>, private val onClick: (Uri) -> Unit)
    : RecyclerView.Adapter<MediaAdapter.ViewHolder>() {

    class ViewHolder(view: View) : RecyclerView.ViewHolder(view) {
        val title: TextView = view.findViewById(R.id.textTitle)
        val path: TextView = view.findViewById(R.id.textPath)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        val view = LayoutInflater.from(parent.context).inflate(R.layout.item_media, parent, false)
        return ViewHolder(view)
    }

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        val (title, uri) = items[position]
        holder.title.text = title
        holder.path.text = uri.toString()
        holder.itemView.setOnClickListener { onClick(uri) }
    }

    override fun getItemCount() = items.size
}
